<template>
  <div class="home">
    <v-row>
      <v-col  cols="12" sm="10" offset-sm="1">     
          <v-container fluid>
            <v-row>
              <v-col v-for="personaje in personajes" :key="personaje.id" class="d-flex child-flex" cols="4">
                <v-card tile class="d-flex flex-column">
                  <v-img :src="personaje.imagen" aspect-ratio="1" class="grey lighten-2"></v-img>  
                    <v-card-title>{{personaje.nombre}}</v-card-title>                 
                </v-card>                  
              </v-col>                    
            </v-row>
          </v-container>        
      </v-col>
    </v-row>  
  </div>
</template>

<script>
// @ is an alias to /src


export default {
  name: 'Home',
  components: {
   
  },
  data() {
    return {
      personajes: [
      {
      'id': 1,
      'nombre': 'Morty',
      'imagen': 'https://rickandmortyapi.com/api/character/avatar/2.jpeg'
      },
      {
      'id': 2,
      'nombre': 'Rick',
      'imagen': 'https://rickandmortyapi.com/api/character/avatar/1.jpeg'
      },
      {
      'id': 3,
      'nombre': 'Summer',
      'imagen': 'https://rickandmortyapi.com/api/character/avatar/3.jpeg'
      },
      {
      'id': 4,
      'nombre': 'Beth',
      'imagen': 'https://rickandmortyapi.com/api/character/avatar/4.jpeg'
      },
      {
      'id': 5,
      'nombre': 'Jerry',
      'imagen': 'https://rickandmortyapi.com/api/character/avatar/5.jpeg'
      }
      ]
    }
  },
}
</script>
